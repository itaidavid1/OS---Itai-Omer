#include "container.h"

/**
 * Initializes a container based on a parent process namespace and runs a program from it.
 * @param args Arguments needed for building the container and running the program from it.
 * @return 0 on success.
 */
int init_container (void* args) {
  // Extract argument struct
  args_st* clone_args = (args_st*) args;
  char** args_arr = clone_args->argsv;
  int prog_argc = clone_args->prog_argc + 1;

  // Extract the arguments that are used by the container
  char* host_name = args_arr[1];
  char* root_dir = args_arr[2];
  char* num_processes = args_arr[3];
  char* program = args_arr[4];

  // Extract the arguments to be passed to the program
  char** program_args = (char**) malloc(sizeof(char*) * prog_argc);
  if (program_args == nullptr) { ERROR(errno) }

  program_args[0] = program;
  for (int i = 1; i < prog_argc; i++) {
      program_args[i] = args_arr[CONTAINER_ARGS - 1 + i];
  }

  // Build the container
  std::string release_value = std::to_string(1);
  std::string cur_pid = std::to_string(getpid());
  int fd;

  if (sethostname(host_name, strlen(host_name) + 1) < 0) { ERROR(errno) }
  if (chroot(root_dir) < 0) { ERROR(errno) }

  std::stringstream path(PATH);
  std::string partial;
  std::string cur_path = "";

  char* access_path;

  while(std::getline(path,partial, '/' )) {
    cur_path += ("/" + partial);
    access_path = const_cast<char*>(cur_path.c_str());
    if (access(access_path, F_OK) != 0) {
        if (mkdir(access_path, MODE) < 0) { ERROR(errno) }
    }
  }

  fd = open(CGROUP_PROCS, O_RDWR | O_CREAT, MODE);
  if (fd < 0) { ERROR(errno) }
  if (write(fd, cur_pid.c_str(), cur_pid.length() + 1) < 0) { ERROR(errno) }
  if (close(fd) < 0) { ERROR(errno) }

  fd = open(PIDS_MAX, O_RDWR | O_CREAT, MODE);
  if (fd < 0) { ERROR(errno) }
  if (write(fd, num_processes, strlen(num_processes) + 1) < 0) { ERROR(errno) }
  if (close(fd) < 0) { ERROR(errno) }

  if (chdir("/") < 0) { ERROR(errno) }
  if (mount("proc", PROC_PATH, "proc", 0, 0) < 0) { ERROR(errno) }

  // Notify the run has finished and return
  fd = open(NOTIFY_RELEASE, O_RDWR | O_CREAT, MODE);
  if (fd < 0) { ERROR(errno) }
  if (write(fd, release_value.c_str(), release_value.length() + 1) < 0) { ERROR(errno) }
  if (close(fd) < 0) { ERROR(errno) }

  // Run the program from within the container
  if (execvp(program, program_args) < 0) { ERROR(errno) }

  return 0;
}

/**
 * Delete a file.
 * @param work_path
 * @param root_dir
 * @param path
 */
void delete_file(char* work_path, char* root_dir, char* path) {
  memset(work_path, 0, PATH_MAX);
  sprintf(work_path, "%s/%s", root_dir, path);
  if (remove(work_path) < 0) { ERROR(errno) }
}

/**
 * Delete a directory.
 * @param work_path
 * @param root_dir
 * @param dir
 */
void delete_dir(char* work_path, char* root_dir, char* dir) {
  memset(work_path, 0, PATH_MAX);
  sprintf(work_path, "%s/%s", root_dir, dir);
  if (rmdir(work_path) < 0) { ERROR(errno) }
}

/**
 * Deletes additional resourced added to file system by the container after it finished running.
 * @param root_dir Path to the root directory of the container
 * @return 0 on success.
 */
int delete_container(char* root_dir) {
  char work_path[PATH_MAX] = {0};

  // Unmount proc file system from the container's root
  sprintf(work_path, "%s%s", root_dir, PROC_PATH);
  if (umount(work_path) < 0) { ERROR(errno) }

  // Delete the files created by container
  delete_file(work_path, root_dir, (char*) CGROUP_PROCS);
  delete_file(work_path, root_dir, (char*) PIDS_MAX);
  delete_file(work_path, root_dir, (char*) NOTIFY_RELEASE);

  // Delete additional directories added by container
  delete_dir (work_path, root_dir,(char*)"/sys/fs/cgroup/pids");
  delete_dir (work_path, root_dir,(char*)"/sys/fs/cgroup");
  delete_dir (work_path, root_dir,(char*)"/sys/fs");

  return 0;
}

int main (int argc, char* argv[]) {
  char* root_dir = argv[2];
  void* stack = malloc(STACK);
  if (stack == nullptr) { ERROR(errno) }

  // Create args for container
  args_st* clone_args = (args_st*) malloc(sizeof (args_st));
  if (clone_args == nullptr) { ERROR(errno) }
  clone_args->prog_argc = argc - CONTAINER_ARGS + 1;
  clone_args->argsv = (char**) malloc(sizeof(char*) * (argc + 1));
  if (clone_args->argsv == nullptr) { ERROR(errno) }
  for (int i = 0; i < argc; i++) {
      clone_args->argsv[i] = argv[i];
    }
  clone_args->argsv[argc] = (char*) nullptr;

  // Create a container by cloning the current process namespace
  clone(&init_container, stack, CONTAINER_FLAGS, clone_args);

  // Wait until the container finishes running and delete unnecessary resources created by it.
  if (wait(nullptr) < 0) { ERROR(errno) }
  delete_container(root_dir);

  return 0;
}