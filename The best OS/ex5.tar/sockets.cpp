#include "sockets.h"

/**
 * Create a new socket, and sets s_fd to hold it's file descriptor and sock_addr to hold its address struct.
 * @param port Port of the socket.
 * @param sock_addr Pointer to sockaddr_in struct to be set in this function.
 * @param s_fd Pointer of socket's FD to be set in this function.
 * @param host_name Name of the host.
 * @return 0 on success, errno otherwise, according to error failure.
 */
int establish_connection(unsigned short port, sockaddr_in* sock_addr, int* s_fd, char* host_name) {
  // Extract the host
  struct hostent* host;
  host = gethostbyname(host_name);
  if (host == nullptr) return errno;

  // Define an address for the new socket
  sock_addr->sin_family = (sa_family_t) host->h_addrtype;
  sock_addr->sin_port = htons((u_short) port);
  memcpy(&sock_addr->sin_addr, host->h_addr, host->h_length);

  // Create a new socket
  if((*s_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) return errno;

  return 0;
}

/**
 * Read a terminal command from the client to a buffer.
 * @param s_fd client socket file descriptor
 * @param buffer buffer to load the command to
 * @return 0 on success, errno on failure.
 */
int read_command(int s_fd, char* buffer) {
  int bcount = 0;
  int br;

  while (bcount < BUFF_SIZE) {
    br = read(s_fd, buffer, BUFF_SIZE-bcount);
    if (br > 0) {
      bcount += br;
      buffer += br;
    }
    else if (br == 0) return 0;
    else return errno;
  }

  return 0;
}

/**
 * Creates a socket for a client to send commands to a server.
 * @param port Port of the socket.
 * @param command The command to run on the server.
 * @return 0 on success, errno otherwise, according to error failure.
 */
int client(unsigned short port, char* command) {
  int s_fd;
  char host_name[BUFF_SIZE];
  struct sockaddr_in sock_addr{};

  if (gethostname(host_name, BUFF_SIZE) < 0) return errno;
  if (establish_connection(port, &sock_addr, &s_fd, host_name) != 0) return errno;

  // Connect to server via socket
  if (connect (s_fd, (struct sockaddr*) &sock_addr, sizeof (sock_addr)) < 0) {
    close(s_fd);
    return errno;
  }

  // Send command via open socket connection on given port
  if (write(s_fd, command, strlen(command) + 1) < 0) {
    close(s_fd);
    return errno;
  }
  if (close (s_fd) < 0) return errno;
  return 0;
}

/**
 * Creates socket for a server to listen on.
 * @param port Port of the socket.
 * @return 0 on success, errno otherwise, according to error failure.
 */
int server(unsigned short port) {
  int s_fd;
  char buffer[BUFF_SIZE];
  struct sockaddr_in sock_addr{};

  if (gethostname(buffer, BUFF_SIZE) < 0) return errno;
  if (establish_connection(port, &sock_addr, &s_fd, buffer) != 0) return errno;
  if (bind (s_fd, (struct sockaddr*) &sock_addr, sizeof(sockaddr_in)) < 0) return errno;

  listen(s_fd, MAX_CONNECTIONS);
  memset(buffer, 0, BUFF_SIZE);

  // Listening on port waiting for clients to send requests.
  while (true) {
    int client_fd;
    if ((client_fd = accept(s_fd, nullptr, nullptr)) < 0) return errno;
    if(read_command(client_fd, buffer) != 0) return errno;
    system(buffer);
    close (client_fd);
  }
  return 0;
}

int main(int argc, char* argv[]) {
  unsigned short port = strtol(argv[2], nullptr, 10);
  char* command;
  int run_socket = 0;

  // Run client socket
  if (strcmp(argv[1], CLIENT) == 0) {
    command = (char*)argv[3];
    run_socket = client(port, command);
  }

  // Run server socket
  if (strcmp(argv[1], SERVER) == 0) {
    run_socket = server(port);
  }

  // System error has been raised
  if (run_socket != 0) { ERROR(run_socket) }
  return 0;
}