#ifndef _SOCKETS_H_
#define _SOCKETS_H_

#include <iostream>
#include <unistd.h>
#include <cstring>
#include <string>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#define BUFF_SIZE 256
#define MAX_CONNECTIONS 5
#define CLIENT "client"
#define SERVER "server"
#define ERROR(errno) std::cerr << "system error: " << strerror(errno) << std::endl; exit(errno);

#endif //_SOCKETS_H_
