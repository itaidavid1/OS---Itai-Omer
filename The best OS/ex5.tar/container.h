#ifndef _CONTAINER_H_
#define _CONTAINER_H_

#include <stdio.h>
#include <iostream>
#include <sched.h>
#include <unistd.h>
#include <cstring>
#include <sstream>
#include <filesystem>
#include <sys/stat.h>
#include <sys/mount.h>
#include <csignal>
#include <sys/wait.h>
#include <fcntl.h>
#include <linux/limits.h>

#define STACK 8192
#define CONTAINER_FLAGS CLONE_NEWUTS | CLONE_NEWPID | CLONE_NEWNS | SIGCHLD
#define MODE 0755
#define CONTAINER_ARGS 5
#define PATH "/sys/fs/cgroup/pids"
#define PROC_PATH "/proc"
#define CGROUP_PROCS "/sys/fs/cgroup/pids/cgroup.procs"
#define PIDS_MAX "/sys/fs/cgroup/pids/pids.max"
#define NOTIFY_RELEASE "/sys/fs/cgroup/pids/notify_on_release"
#define ERROR(errno) std::cerr << "system error: " << strerror(errno) << std::endl; exit(errno);

/**
 * Struct of arguments to send to a container.
 */
typedef struct args_st {
  char** argsv;
  int prog_argc;
} args_st;

#endif //_CONTAINER_H_
