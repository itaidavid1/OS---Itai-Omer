#include "VirtualMemory.h"
#include "PhysicalMemory.h"
#include <cmath>

/**
 * Traversing the virtual address tree in order to find an available frame.
 * If find an empty frame return its index.
 * Update the max_frame_idx pointer to the maximal frame index reached.
 * Update the evict_frame pointer with the frame holding the page with the maximal cyclical distance.
 * @param cur_frame
 * @param cur_layer
 * @param max_frame_idx
 * @param evict_frame
 * @param evict_page
 * @param parent_evict
 * @param max_cyc_diff
 * @param page_in
 * @param page_out
 * @param parent
 * @param prev_frame
 * @return Index of am empty frame if exists, else 0.
 */
int dfs(int cur_frame, int cur_layer, int* max_frame_idx, int* evict_frame, int* evict_page,
        int* parent_evict, int *max_cyc_diff, uint64_t page_in, uint64_t page_out, int parent, int prev_frame) {

  // Update max frame reached
  (*max_frame_idx) = fmax((*max_frame_idx), cur_frame);

  // Reached the lowest layer of the table tree.
  if (cur_layer == TABLES_DEPTH) {
      // Calculate cyclic difference, and save current page_out if difference is maximal.
      int cur_diff = page_in > page_out ? (page_in - page_out) : page_out - page_in;
      int cur_cyc_diff = fmin(NUM_PAGES - cur_diff, cur_diff);

      if (cur_cyc_diff > (*max_cyc_diff) && (cur_frame != prev_frame)) {
        (*evict_frame) = cur_frame;
        (*evict_page) = page_out;
        (*parent_evict) = parent;
        (*max_cyc_diff) = cur_cyc_diff;
      }
      return 0;
    }

  bool empty_frame = true;

  // Traversing through the current frame children frames.
  for (int i = 0; i < PAGE_SIZE; ++i) {
    int child_frame = 0;
    PMread(cur_frame * PAGE_SIZE + i, &child_frame);
    if (child_frame != 0)  {
      empty_frame = false;
      int frame_found = dfs(child_frame, cur_layer + 1, max_frame_idx,
                            evict_frame, evict_page, parent_evict, max_cyc_diff, page_in,
                            page_out * PAGE_SIZE + i,cur_frame, prev_frame);
      if (frame_found != 0) {
        // Unlink from parent
        if (frame_found == child_frame) {
          PMwrite(cur_frame * PAGE_SIZE + i, 0);
        }
        return frame_found;
      }
    }
  }

  // Found an empty frame
  if (empty_frame && (cur_frame != prev_frame)) {
    return cur_frame;
  }
  return 0;
}


/**
 *  Find an available frame in the physical memory.
 * @return Address of the physical memory available on success, 0 on failure.
 */
int find_available_frame(uint64_t page_in, int prev_frame) {
  int max_frame_idx = 0;
  int evict_frame = 0;
  int evict_page = 0;
  int parent_evict = 0;
  int max_cyc_diff = 0;


  int empty_frame = dfs(0, 0, &max_frame_idx, &evict_frame,
                        &evict_page, &parent_evict,&max_cyc_diff,
                        page_in, 0, 0, prev_frame);

  // Found empty frame
  if (empty_frame != 0) {
    return empty_frame;
  }

  // Found unused frame
  if (max_frame_idx + 1 < NUM_FRAMES) {
    for (int i = 0; i < PAGE_SIZE; ++i) {
      PMwrite((max_frame_idx + 1) * PAGE_SIZE + i, 0);
    }
    return max_frame_idx + 1;
  }

  // No empty or unused frame found, need to evict frame
  if (evict_frame != 0) {
    // Initialize the evicted frame
    PMevict(evict_frame, evict_page);
    for (int i = 0; i < PAGE_SIZE; ++i) {
      PMwrite(evict_frame * PAGE_SIZE + i, 0);

      // Unlink the evicted frame from parent
      int place_holder = 0;
      PMread(parent_evict * PAGE_SIZE + i, &place_holder);
      if (place_holder == evict_frame) {
        PMwrite(parent_evict * PAGE_SIZE + i, 0);
      }
    }
    return evict_frame;
  }
  return 0;
}

/**
 * Maps the given virtual address to a physical address, using a hierarchical page table mapping algorithm.
 * Sets the physicalAddress pointer with the address found.
 * @param virtualAddress
 * @param physicalAddress
 * @return 1 on success, 0 otherwise
 */
int multilevel_mapping(uint64_t virtualAddress, uint64_t* physicalAddress) {
  if (virtualAddress >= VIRTUAL_MEMORY_SIZE) return 0;

  int frame = 0;
  int bit_page_size = (int)(log2(PAGE_SIZE));
  uint64_t bit_mask = (PAGE_SIZE - 1) << (bit_page_size * (TABLES_DEPTH - 1));
  uint64_t cur_virtual_ad, offset_ad;
  uint64_t physical_ad = 0;

  // Iterating through virtual address segments
  for (int i = 0; i < TABLES_DEPTH ; ++i) {
      // Extract current relative virtual address
      cur_virtual_ad = ((virtualAddress >> OFFSET_WIDTH) & bit_mask) >> ((TABLES_DEPTH - 1 - i) * bit_page_size);
      bit_mask /= PAGE_SIZE;

      // Find next frame in path if already mapped
      PMread(physical_ad * PAGE_SIZE + cur_virtual_ad, &frame);

      // Find available frame for the current path if not mapped
      if (frame == 0) {
        frame = find_available_frame((virtualAddress >> OFFSET_WIDTH), physical_ad);
        if(frame != 0) {
          PMwrite(physical_ad * PAGE_SIZE + cur_virtual_ad, frame);
        }
        // No available frame found, page-fault.
        else return 0;
      }
      physical_ad = frame;
  }

  // Swap the desired page from the hard drive into the mapped frame in the RAM
  PMrestore(physical_ad, (virtualAddress >> OFFSET_WIDTH));

  // Set the physical address to the specific word in the frame we want to access.
  offset_ad = virtualAddress % PAGE_SIZE;
  (*physicalAddress) = physical_ad * PAGE_SIZE + offset_ad;

  return 1;
}

//=============================================================================

/*
 * Initialize the virtual memory.
 */
void VMinitialize() {
  for (uint64_t i = 0; i < PAGE_SIZE; ++i) {
      PMwrite(i, 0);
  }
}

/* Reads a word from the given virtual address
 * and puts its content in *value.
 *
 * returns 1 on success.
 * returns 0 on failure (if the address cannot be mapped to a physical
 * address for any reason)
 */
int VMread(uint64_t virtualAddress, word_t* value) {
  uint64_t physicalAddress = 0;
  if (multilevel_mapping(virtualAddress, &physicalAddress) == 0) {
      return 0;
  }
  PMread(physicalAddress, value);
  return 1;
}

/* Writes a word to the given virtual address.
 *
 * returns 1 on success.
 * returns 0 on failure (if the address cannot be mapped to a physical
 * address for any reason)
 */
int VMwrite(uint64_t virtualAddress, word_t value) {
  uint64_t physicalAddress = 0;
  if (multilevel_mapping(virtualAddress, &physicalAddress) == 0) {
      return 0;
  }
  PMwrite(physicalAddress, value);
  return 1;
}