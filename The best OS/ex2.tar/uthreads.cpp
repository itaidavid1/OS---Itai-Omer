#include <cstdlib>
#include <csetjmp>
#include <cstdio>
#include <iostream>
#include <csignal>
#include <sys/time.h>
#include <unordered_set>
#include <vector>
#include <algorithm>
#include "uthreads.h"

//--------------------------------Macros---------------------------------------
#define JB_SP 6
#define JB_PC 7
#define FAILURE -1

/**
 * Error Macros
 */
#define ERR_QUANTUM "thread library error: Quantum value is invalid."
#define ERR_SIGACTION "system error: Failed setting signal action."
#define ERR_SETITIMER "system error: Failed setting timer action."
#define ERR_SPAWN "thread library error: Can't add new thread."
#define ERR_TERMINATE "thread library error: There is no thread by this ID."
#define ERR_BLOCK "thread library error: Can't block this thread."
#define ERR_RESUME "thread library error: Can't resume this thread."
#define ERR_RUNNING "thread library error: No thread currently running."
#define ERR_SLEEP "thread library error: Can't sent this thread to sleep for the time given."
#define ERR_SIGMSK "system error: Can't change signal mask."

//--------------------------------Thread---------------------------------------
/**
 * Type that describes memory address.
 */
typedef unsigned long address_t;

/**
 * A translation is required when using an address of a variable.
 * @param addr
 * @return translated address.
 */
address_t translate_address(address_t addr) {
  address_t ret;
  asm volatile("xor    %%fs:0x30,%0\n"
               "rol    $0x11,%0\n"
  : "=g" (ret)
  : "0" (addr));
  return ret;
}

/**
 * Type that describes thread state.
 */
typedef enum State {
  READY, RUNNING, BLOCKED
} State;

/**
 * Struct describing a single thread, creating and defining a single Thread
 * object.
 */
typedef struct Thread {
  int tid;
  State state;
  thread_entry_point entry_point;
  int quantum_count;
  int sleep_quantum;
  char* stack;
  sigjmp_buf env;

  /**
   * Thread Constructor.
   * @param tid - ID for created thread.
   * @param entry_point - Entry point function for created thread.
   */
  Thread (int tid, thread_entry_point entry_point) {
    this->tid = tid;
    this->entry_point = entry_point;
    this->quantum_count = 0;
    this->sleep_quantum = 0;
    this->state = READY;
    this->stack = new char[STACK_SIZE];
    setup_thread();
  }

  /**
   * Thread destructor.
   */
  ~Thread(){
    delete[] this->stack;
  }

  /**
   *  initializes env to use the right stack, and to run from the function 'entry_point', when we'll use
   *  siglongjmp to jump into the thread.
   */
  void setup_thread() {
    sigsetjmp(env, 1);
    if (this->entry_point != nullptr) {
        address_t sp = (address_t) stack + STACK_SIZE - sizeof(address_t);
        address_t pc = (address_t) entry_point;
        (env->__jmpbuf)[JB_SP] = translate_address(sp);
        (env->__jmpbuf)[JB_PC] = translate_address(pc);
    }
    sigemptyset(&(env->__saved_mask));
  }

} Thread;

//--------------------------------Globals--------------------------------------

std::vector<Thread*> allThreads;
std::vector<Thread*> readyThreads;
std::unordered_set<Thread*> sleepThreads;
Thread* runningThread;
int quantum_count;

/**
 * Exits thr program after freeing all allocated memory.
 * @param status - Exit status, EXIT_SUCCESS or EXIT_FAILURE
 */
void exit_free(int status) {
  allThreads.clear();
  readyThreads.clear();
  sleepThreads.clear();
  delete runningThread;
  exit(status);
}

//-------------------------------Scheduler-------------------------------------

/**
 * Scheduler object, holds a sigaction object and an itimerval object.
 */
namespace Scheduler {
  struct sigaction sa = {0};
  struct itimerval timer;
  sigset_t global_sigset;

  /**
   * Start the timer with the given interval.
   */
  void start_timer() {
    if (setitimer(ITIMER_VIRTUAL, &timer, nullptr)) {
        std::cerr << ERR_SETITIMER << std::endl;
        exit_free(EXIT_FAILURE);
    }
  }

  /**
   * update the sleep quantum of the sleeping thread
   */
  void update_sleep_thread()
  {
    std::unordered_set<Thread*> wake_up;

    for (auto thread : sleepThreads) {
        thread->sleep_quantum--;
        if (thread->sleep_quantum == 0) {
            if (thread->state == READY) {
                readyThreads.push_back(thread);
            }
            wake_up.insert(thread);
        }
    }

    for(auto thread: wake_up){
      auto iter = sleepThreads.find(thread);
      sleepThreads.erase(iter);
    }

    wake_up.clear();
  }

  /**
  * Changes the global signal mask to block or unblock SIGVTALRM.
  * @param action - defines whether to block
  * @return
  */
  void change_signal_mask(int action) {
    if (sigprocmask(action, &global_sigset, nullptr) == FAILURE){
        std::cerr << ERR_SIGMSK << std::endl;
        exit_free(EXIT_FAILURE);
    }
  }

  /**
   * Ignores pending SIGVTALRM signals that were stored while blocked by the
   * signal mask, when manual handler is activated.
   */
  void ignore_pending()
  {
    sigset_t pending_sigset;
    if (sigemptyset(&pending_sigset) == FAILURE) {
      std::cerr << ERR_SIGMSK << std::endl;
      exit_free(EXIT_FAILURE);
    }
    if (sigpending(&pending_sigset) == FAILURE){
      std::cerr << ERR_SIGMSK << std::endl;
      exit_free(EXIT_FAILURE);
    }


    if (sigismember(&pending_sigset, SIGVTALRM))
      {
        int ignore_sig;
        if (sigaddset(&pending_sigset, SIGVTALRM) == FAILURE){
            std::cerr << ERR_SIGMSK << std::endl;
            exit_free(EXIT_FAILURE);
        }
        sigwait(&pending_sigset, &ignore_sig);
      }
  }

  /**
   * Handler, handles SIGVTALRM, SIGUSR1, and SIGUSR2 signals.
   * @param sig, The signal to be handled.
   */
  void thread_scheduler(int sig) {
    // Wake up sleeping threads
    update_sleep_thread();

    // Update quantum count
    quantum_count++;

    // Switch threads
    if (!readyThreads.empty()) {
        int cur_tid = runningThread->tid;

        runningThread = readyThreads.front();;
        runningThread->state = RUNNING;
        runningThread->quantum_count++;
        readyThreads.erase(readyThreads.begin());

        // Time of the current thread ran out
        if(sig == SIGVTALRM) {
          readyThreads.push_back(allThreads[cur_tid]);
          allThreads[cur_tid]->state = READY;
        }

        // The running thread terminates
        if(sig == SIGUSR2) {
          delete allThreads[cur_tid];
          allThreads[cur_tid] = nullptr;
          start_timer();
          siglongjmp(runningThread->env, 1);
        }

        else {
          if (sigsetjmp(allThreads[cur_tid]->env, 1) == EXIT_SUCCESS) {
              start_timer();
              siglongjmp(runningThread->env, 1);
          }
        }
    }
    ignore_pending();
  }


  /**
   * Initializes the Scheduler.
   * @param quantum_usecs - length of a quantum in micro-seconds
   */
  void init_scheduler(int quantum_usecs) {
    if (sigemptyset(&global_sigset) == FAILURE) {
      std::cerr << ERR_SIGACTION << std::endl;
      exit_free(EXIT_FAILURE);
    }
    if (sigaddset(&global_sigset, SIGVTALRM) == FAILURE) {
      std::cerr << ERR_SIGACTION << std::endl;
      exit_free(EXIT_FAILURE);
    }

    sa.sa_handler = &thread_scheduler;
    if (sigaction(SIGVTALRM, &sa, nullptr) < 0) {
        std::cerr << ERR_SIGACTION << std::endl;
        exit_free(EXIT_FAILURE);
    }

    timer.it_value.tv_sec = quantum_usecs / 1000000;
    timer.it_value.tv_usec = quantum_usecs % 1000000;

    timer.it_interval.tv_sec = quantum_usecs / 1000000;
    timer.it_interval.tv_usec = quantum_usecs % 1000000;

    quantum_count++;
    start_timer();
  }
}

//----------------------------Library Functions------------__------------------

/**
 * @brief initializes the thread library.
 *
 * Once this function returns, the main thread (tid == 0) will be set as RUNNING. There is no need to
 * provide an entry_point or to create a stack for the main thread - it will be using the "regular" stack and PC.
 * You may assume that this function is called before any other thread library function, and that it is called
 * exactly once.
 * The input to the function is the length of a quantum in micro-seconds.
 * It is an error to call this function with non-positive quantum_usecs.
 *
 * @return On success, return 0. On failure, return -1.
*/
int uthread_init(int quantum_usecs) {
  Scheduler::change_signal_mask(SIG_BLOCK);

  if (quantum_usecs <= 0 ) {
    std::cerr << ERR_QUANTUM << std::endl;
    return FAILURE;
  }

  quantum_count = 0;
  Scheduler::init_scheduler(quantum_usecs);

  allThreads.push_back(new Thread(0, nullptr));
  runningThread = allThreads[0];
  runningThread->state = RUNNING;
  runningThread->quantum_count++;

  Scheduler::change_signal_mask(SIG_UNBLOCK);
  return EXIT_SUCCESS;
}


/**
 * @brief Creates a new thread, whose entry point is the function entry_point with the signature
 * void entry_point(void).
 *
 * The thread is added to the end of the READY threads list.
 * The uthread_spawn function should fail if it would cause the number of concurrent threads to exceed the
 * limit (MAX_THREAD_NUM).
 * Each thread should be allocated with a stack of size STACK_SIZE bytes.
 * It is an error to call this function with a null entry_point.
 *
 * @return On success, return the ID of the created thread. On failure, return -1.
*/
int uthread_spawn(thread_entry_point entry_point){
  Scheduler::change_signal_mask(SIG_BLOCK);

  if (entry_point == nullptr || allThreads.size() == MAX_THREAD_NUM) {
    std::cerr << ERR_SPAWN << std::endl;
    Scheduler::change_signal_mask(SIG_UNBLOCK);
    return FAILURE;
  }

  auto iter = std::find(allThreads.begin(), allThreads.end(),nullptr);
  int tid = std::distance(allThreads.begin(), iter);

  if (iter == allThreads.end()) {
    allThreads.push_back(new Thread(tid, entry_point));
  }
  else {
    allThreads[tid] = new Thread(tid, entry_point);
  }
  readyThreads.push_back(allThreads[tid]);

  Scheduler::change_signal_mask(SIG_UNBLOCK);
  return tid;
}


/**
 * @brief Terminates the thread with ID tid and deletes it from all relevant control structures.
 *
 * All the resources allocated by the library for this thread should be released. If no thread with ID tid exists it
 * is considered an error. Terminating the main thread (tid == 0) will result in the termination of the entire
 * process using exit(0) (after releasing the assigned library memory).
 *
 * @return The function returns 0 if the thread was successfully terminated and -1 otherwise. If a thread terminates
 * itself or the main thread is terminated, the function does not return.
*/
int uthread_terminate(int tid) {
  Scheduler::change_signal_mask(SIG_BLOCK);

  if (tid >= (int)allThreads.size() || tid < 0 || allThreads[tid] == nullptr) {
    std::cerr << ERR_TERMINATE << std::endl;
    Scheduler::change_signal_mask(SIG_UNBLOCK);
    return FAILURE;
  }

  if (tid == 0) {
    exit_free(EXIT_SUCCESS);
  }

  if (allThreads[tid]->state == RUNNING) {
      Scheduler::thread_scheduler(SIGUSR2);
  }

  if (allThreads[tid]->sleep_quantum > 0) {
      auto iter = sleepThreads.find(allThreads[tid]);
      sleepThreads.erase(iter);
  }

  else if (allThreads[tid]->state == READY) {
    auto iter = std::find(readyThreads.begin(), readyThreads.end(),
                          allThreads[tid]);
    readyThreads.erase(iter);
  }

  delete allThreads[tid];
  allThreads[tid] = nullptr;

  Scheduler::change_signal_mask(SIG_UNBLOCK);
  return EXIT_SUCCESS;
}


/**
 * @brief Blocks the thread with ID tid. The thread may be resumed later using uthread_resume.
 *
 * If no thread with ID tid exists it is considered as an error. In addition, it is an error to try blocking the
 * main thread (tid == 0). If a thread blocks itself, a scheduling decision should be made. Blocking a thread in
 * BLOCKED state has no effect and is not considered an error.
 *
 * @return On success, return 0. On failure, return -1.
*/
int uthread_block(int tid){
  Scheduler::change_signal_mask(SIG_BLOCK);

  if (tid >= (int)allThreads.size() || tid <= 0 || allThreads[tid] == nullptr){
      std::cerr << ERR_BLOCK << std::endl;
      Scheduler::change_signal_mask(SIG_UNBLOCK);
      return FAILURE;
  }

  if (allThreads[tid]->state == RUNNING) {
      Scheduler::thread_scheduler(SIGUSR1);
  }

  if (allThreads[tid]->state == READY && allThreads[tid]->sleep_quantum == 0) {
      auto iter = std::find(readyThreads.begin(), readyThreads.end(),
                            allThreads[tid]);
      readyThreads.erase(iter);
  }

  allThreads[tid]->state = BLOCKED;

  Scheduler::change_signal_mask(SIG_UNBLOCK);
  return EXIT_SUCCESS;
}


/**
 * @brief Resumes a blocked thread with ID tid and moves it to the READY state.
 *
 * Resuming a thread in a RUNNING or READY state has no effect and is not considered as an error. If no thread with
 * ID tid exists it is considered an error.
 *
 * @return On success, return 0. On failure, return -1.
*/
int uthread_resume(int tid){
  if (tid >= (int)allThreads.size() || tid < 0 || allThreads[tid] == nullptr) {
      std::cerr << ERR_RESUME << std::endl;
      return FAILURE;
  }

  if (allThreads[tid]->state == BLOCKED) {
    if (allThreads[tid]->sleep_quantum == 0) {
        readyThreads.push_back(allThreads[tid]);
    }
    allThreads[tid]->state = READY;
  }

  return EXIT_SUCCESS;
}


/**
 * @brief Blocks the RUNNING thread for num_quantums quantums.
 *
 * Immediately after the RUNNING thread transitions to the BLOCKED state a scheduling decision should be made.
 * After the sleeping time is over, the thread should go back to the end of the READY queue.
 * If the thread which was just RUNNING should also be added to the READY queue, or if multiple threads wake up
 * at the same time, the order in which they're added to the end of the READY queue doesn't matter.
 * The number of quantums refers to the number of times a new quantum starts, regardless of the reason. Specifically,
 * the quantum of the thread which has made the call to uthread_sleep isn’t counted.
 * It is considered an error if the main thread (tid == 0) calls this function.
 *
 * @return On success, return 0. On failure, return -1.
*/
int uthread_sleep(int num_quantums) {
  Scheduler::change_signal_mask(SIG_BLOCK);

  if (runningThread == nullptr || runningThread->tid == 0 || num_quantums <= 0) {
      std::cerr << ERR_SLEEP << std::endl;
      return FAILURE;
  }

  runningThread->sleep_quantum = num_quantums;
  runningThread->state = READY;

  sleepThreads.insert(runningThread);
  Scheduler::thread_scheduler(SIGUSR1);

  Scheduler::change_signal_mask(SIG_UNBLOCK);
  return EXIT_SUCCESS;
}


/**
 * @brief Returns the thread ID of the calling thread.
 *
 * @return The ID of the calling thread.
*/
int uthread_get_tid(){
  if (runningThread == nullptr) {
    std::cerr << ERR_RUNNING << std::endl;
    return FAILURE;
  }
  return runningThread->tid;
}


/**
 * @brief Returns the total number of quantums since the library was initialized, including the current quantum.
 *
 * Right after the call to uthread_init, the value should be 1.
 * Each time a new quantum starts, regardless of the reason, this number should be increased by 1.
 *
 * @return The total number of quantums.
*/
int uthread_get_total_quantums(){
  return quantum_count;
}


/**
 * @brief Returns the number of quantums the thread with ID tid was in RUNNING state.
 *
 * On the first time a thread runs, the function should return 1. Every additional quantum that the thread starts should
 * increase this value by 1 (so if the thread with ID tid is in RUNNING state when this function is called, include
 * also the current quantum). If no thread with ID tid exists it is considered an error.
 *
 * @return On success, return the number of quantums of the thread with ID tid. On failure, return -1.
*/
int uthread_get_quantums(int tid){
  if (tid >= (int)allThreads.size() || tid < 0 || allThreads[tid] == nullptr) {
      std::cerr << ERR_BLOCK << std::endl;
      return FAILURE;
    }
  return allThreads[tid]->quantum_count;
}