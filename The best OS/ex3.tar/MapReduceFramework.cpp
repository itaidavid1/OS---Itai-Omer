#include "MapReduceFramework.h"
#include "Barrier.h"
#include <map>
#include <pthread.h>
#include <atomic>
#include <algorithm>
#include <iostream>

// ------------------------MACROS--------------------------//

#define ERR_CREATE_T "system error: create thread failed \n"
#define ERR_JOIN_T "system error: joining threads failed \n"
#define ERR_MUTEX_LOCK "system error: lock mutex failed \n"
#define ERR_MUTEX_UNLOCK "system error: unlock mutex failed \n"
#define ERR_MUTEX_DESTROY "system error: destroy mutex failed \n"

#define BIT_MASK ((1U<<31) - 1)

// ------------------------Structs--------------------------//

/**
 * Struct holding context of a single thread.
 */
typedef struct ThreadContext {
  IntermediateVec intermediate_vec;
  std::atomic<int>* intermediate_counter;
} ThreadContext;

/**
 * Struct holding context of the multi-thread job.
 */
typedef struct JobContext {
  int num_threads;
  pthread_t* threads;
  ThreadContext* contexts;
  std::atomic<int> intermediate_counter;
  std::atomic<int> input_output_counter;
  std::atomic<uint64_t> job_state;
  const MapReduceClient& client;
  const InputVec& input_vec;
  std::vector<IntermediateVec> shuffle_vec;
  OutputVec& output_vec;
  Barrier barrier;
  bool wait_for_job;
  bool state_initialized;
  pthread_mutex_t reduce_mutex;
  pthread_mutex_t write_output_mutex;
  pthread_mutex_t wait_join_mutex;
  pthread_mutex_t update_state_mutex;
} JobContext;

typedef std::pair<JobContext* , int> JobTID;

// ------------------------Helper functions--------------------------//

/**
 * Initialize the atomic state variable according to the new state started.
 * @param job_context
 * @param stage
 * @param total_size
 */
void initialize_state(JobContext* job_context, stage_t stage, int total_size) {
  if (pthread_mutex_lock (&job_context->update_state_mutex) != 0) {
    std::cerr << ERR_MUTEX_LOCK << std::endl;
    exit(1);
  }

  if (!(job_context->state_initialized)) {
      job_context->state_initialized = true;
      job_context->job_state = ((unsigned long)(stage) << 62) +
          ((unsigned long)(total_size) << 31);
    }
  if (pthread_mutex_unlock (&job_context->update_state_mutex) != 0) {
    std::cerr << ERR_MUTEX_UNLOCK << std::endl;
    exit(1);
  }
}


/**
 * Take element from input vector and call client map.
 * @param job_context
 * @param tid
 */
void map_phase(JobContext* job_context, int tid) {
  initialize_state(job_context, MAP_STAGE, (int)job_context->input_vec.size());

  while (true) {
      int input_idx = (job_context->input_output_counter)++;
      if (input_idx >= (int)job_context->input_vec.size()) {
          break;
      }
      job_context->job_state++;
      InputPair pair = job_context->input_vec[input_idx];
      job_context->client.map(pair.first, pair.second,
                              (void*) &(job_context->contexts[tid]));
    }
}


/**
 * Sort the intermediate vector of the running thread.
 * @param job_context
 * @param tid
 */
void sort_phase(JobContext* job_context, int tid) {
  auto cur_vec = job_context->contexts[tid].intermediate_vec;
  std::sort(cur_vec.begin(), cur_vec.end());
}


/**
 * Iterates the contexts of the threads, creates new vectors with the same key,
 * and put them in the shuffle vector
 * @param job_context
 */
void shuffle_phase(JobContext* job_context) {
  int num_intermediate = job_context->intermediate_counter.load();
  int num_shuffle = 0;
  job_context->job_state = (2UL << 62) + ((unsigned long)(num_intermediate) << 31);

  job_context->intermediate_counter = 0;
  job_context->input_output_counter = 0;
  job_context->state_initialized = false;

  struct compare_K2_pointer { bool operator()(const K2* a, const K2* b) const { return *a < *b; } };
  std::map<K2*, IntermediateVec, compare_K2_pointer> vectorize_pairs;

  while (num_shuffle < num_intermediate) {
    for (int i = 0; i < job_context->num_threads; ++i) {
      IntermediateVec* vec = &(job_context->contexts[i].intermediate_vec);
      if (!vec->empty()) {
          num_shuffle++;
          IntermediatePair pair = vec->back();
          if (vectorize_pairs.count(pair.first) <= 0) {
              vectorize_pairs[pair.first] = *(new IntermediateVec);
          }
          vectorize_pairs[pair.first].push_back(pair);
          vec->pop_back();
          job_context->job_state++;
      }
    }
  }

  for (std::pair<K2*, IntermediateVec> map_pair : vectorize_pairs) {
    job_context->shuffle_vec.push_back(map_pair.second);
    job_context->intermediate_counter++;
  }
}


/**
 * Take element from shuffle vector and call client reduce.
 * @param job_context
 * @param tid
 */
void reduce_phase(JobContext* job_context) {
  int num_shuffle = job_context->intermediate_counter.load();
  initialize_state(job_context, REDUCE_STAGE, num_shuffle);

  while (true) {
    if (pthread_mutex_lock(&(job_context->reduce_mutex)) != 0) {
      std::cerr << ERR_MUTEX_LOCK << std::endl;
      exit(1);
    }
    if (!(job_context->shuffle_vec.empty())) {
        const IntermediateVec vec = job_context->shuffle_vec.back();
        job_context->shuffle_vec.pop_back();
        if (pthread_mutex_unlock(&(job_context->reduce_mutex)) != 0) {
          std::cerr << ERR_MUTEX_UNLOCK << std::endl;
          exit(1);
        }
        job_context->client.reduce(&vec, (void*)(job_context));
        job_context->job_state++;
    }
    else {
        if (pthread_mutex_unlock(&(job_context->reduce_mutex)) != 0) {
          std::cerr << ERR_MUTEX_UNLOCK << std::endl;
          exit(1);
        }
        break;
    }
  }
}


/**
 * The thread's function.
 * @param arg
 * @return
 */
void* start_thread_map_reduce(void* arg) {
  JobTID* jt = (JobTID*) arg;
  JobContext* job_context = jt->first;
  int tid = jt->second;

  map_phase(job_context, tid);
  sort_phase(job_context, tid);
  job_context->barrier.barrier();
  if (tid == 0) {
    shuffle_phase(job_context);
  }
  job_context->barrier.barrier();
  reduce_phase(job_context);
  return nullptr;
}

// ------------------------Library functions--------------------------//


/**
 * Make IntermediatePair with key amd value, and put it in the input context.
 * @param key
 * @param value
 * @param context
 */
void emit2 (K2* key, V2* value, void* context) {
  ThreadContext* thread_context = (ThreadContext*) context;
  thread_context->intermediate_vec.push_back(IntermediatePair(key, value));
  (*(thread_context->intermediate_counter))++;
}


/**
 * Make OutputPair with key amd value, and put it in the input context.
 * @param key
 * @param value
 * @param context
 */
void emit3 (K3* key, V3* value, void* context) {
  JobContext* job_context = (JobContext*) context;

  if (pthread_mutex_lock(&(job_context->write_output_mutex)) != 0) {
    std::cerr << ERR_MUTEX_LOCK << std::endl;
    exit(1);
  }
  job_context->output_vec.push_back(OutputPair(key, value));
  if (pthread_mutex_unlock(&(job_context->write_output_mutex)) != 0) {
    std::cerr << ERR_MUTEX_UNLOCK << std::endl;
    exit(1);
  }

  job_context->input_output_counter++;
}


/**
 * Starts running the MapReduce algorithm
 * @param client
 * @param inputVec
 * @param outputVec
 * @param multiThreadLevel
 * @return JobHandle
 */
JobHandle startMapReduceJob(const MapReduceClient& client,
                            const InputVec& inputVec, OutputVec& outputVec,
                            int multiThreadLevel) {

  JobContext* job_context = new JobContext {
      .num_threads = multiThreadLevel,
      .threads = new pthread_t[multiThreadLevel],
      .contexts = new ThreadContext[multiThreadLevel],
      .intermediate_counter= {0},
      .input_output_counter = {0},
      .job_state = {0},
      .client = client,
      .input_vec = inputVec,
      .output_vec = outputVec,
      .barrier = {multiThreadLevel},
      .wait_for_job = false,
      .state_initialized = false,
      .reduce_mutex = PTHREAD_MUTEX_INITIALIZER,
      .write_output_mutex = PTHREAD_MUTEX_INITIALIZER,
      .wait_join_mutex = PTHREAD_MUTEX_INITIALIZER,
      .update_state_mutex = PTHREAD_MUTEX_INITIALIZER
  };

  for (int i = 0; i < multiThreadLevel; ++i) {
      job_context->contexts[i] = ThreadContext {
          .intermediate_counter = &job_context->intermediate_counter
      };
      if (pthread_create(&(job_context->threads[i]),
                     nullptr,
                     start_thread_map_reduce,
                     (void*) new JobTID(job_context, i)) != 0) {
        std::cerr << ERR_CREATE_T << std::endl;
        exit(1);
      }
    }

  return static_cast<JobHandle>(job_context);
}


/**
 * Waits until the JobHandle job is finished.
 * @param job
 */
void waitForJob(JobHandle job) {
  JobContext* job_context = (JobContext*) job;
  if (pthread_mutex_lock(&(job_context->wait_join_mutex)) != 0) {
    std::cerr << ERR_MUTEX_LOCK << std::endl;
    exit(1);
  }

  if (!(job_context->wait_for_job)) {
    job_context->wait_for_job = true;
    for (int i = 0; i < job_context->num_threads; ++i) {
      if (pthread_join(job_context->threads[i], nullptr) != 0) {
        std::cerr << ERR_JOIN_T << std::endl;
        exit(1);
      }
    }
  }
  if (pthread_mutex_unlock(&(job_context->wait_join_mutex)) != 0) {
    std::cerr << ERR_MUTEX_UNLOCK << std::endl;
    exit(1);
  }
}

/**
 * Updates the state of JobHandle job into the given JobState struct
 * @param job
 * @param state
 */
void getJobState(JobHandle job, JobState* state) {
  JobContext* job_context = (JobContext*) job;
  unsigned long job_state_buff = job_context->job_state.load();

  state->stage = static_cast<stage_t>(job_state_buff>>62);

  auto total = (float)(job_state_buff>>31 & BIT_MASK);
  auto counter = (float)(job_state_buff & BIT_MASK);
  state->percentage = total == 0 ? 0 : 100 * (counter/total);
}


/**
 * Releasing all the resources of the JobHandle job.
 * @param job
 */
void closeJobHandle(JobHandle job){
  waitForJob(job);
  JobContext* job_context = (JobContext*) job;

  if (pthread_mutex_destroy(&(job_context->reduce_mutex)) != 0) {
    std::cerr << ERR_MUTEX_DESTROY << std::endl;
    exit(1);
  }
  if (pthread_mutex_destroy(&(job_context->write_output_mutex)) != 0) {
    std::cerr << ERR_MUTEX_DESTROY << std::endl;
    exit(1);
  }
  if (pthread_mutex_destroy(&(job_context->wait_join_mutex)) != 0) {
    std::cerr << ERR_MUTEX_DESTROY << std::endl;
    exit(1);
  }

  delete[] job_context->threads;
  delete[] job_context->contexts;
  delete job_context;
}