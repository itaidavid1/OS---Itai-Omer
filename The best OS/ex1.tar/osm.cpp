#include "osm.h"
#include <sys/time.h>

/* Time measurement function for a simple arithmetic operation.
   returns time in nano-seconds upon success,
   and -1 upon failure.
   */
double osm_operation_time(unsigned int iterations){
  if (iterations == 0) return -1;

  struct timeval start, end;

  int x = 0;
  if (gettimeofday(&start, nullptr) == -1) return -1;
  for (int i = 0; i < iterations; ++i){
      x += 2;
  }
  if (gettimeofday(&end, nullptr) == -1) return -1;
  double diff = ((end.tv_sec * 1e9 + end.tv_usec * 1e3) -
                 (start.tv_sec *1e9 + start.tv_usec * 1e3));
  return diff / (double) iterations;
}

/*
 * Empty function for empty function call test.
 */
void empty_function(){}

/* Time measurement function for an empty function call.
   returns time in nano-seconds upon success,
   and -1 upon failure.
   */
double osm_function_time(unsigned int iterations){
  if (iterations == 0) return -1;

  struct timeval start, end;
  if (gettimeofday(&start, nullptr) == -1) return -1;
  for (int i = 0; i < iterations; ++i){
      empty_function();
    }
  if (gettimeofday(&end, nullptr) == -1) return -1;
  double diff = ((end.tv_sec * 1e9 + end.tv_usec * 1e3) -
                 (start.tv_sec *1e9 + start.tv_usec * 1e3));
  return diff / (double) iterations;
}


/* Time measurement function for an empty trap into the operating system.
   returns time in nano-seconds upon success,
   and -1 upon failure.
   */
double osm_syscall_time(unsigned int iterations){
  if (iterations == 0) return -1;

  struct timeval start, end;
  if (gettimeofday(&start, nullptr) == -1) return -1;
  for (int i = 0; i < iterations; ++i){
    OSM_NULLSYSCALL;
  }
  if (gettimeofday(&end, nullptr) == -1) return -1;
  double diff = ((end.tv_sec * 1e9 + end.tv_usec * 1e3) -
      (start.tv_sec *1e9 + start.tv_usec * 1e3));
  return diff / (double) iterations;
}